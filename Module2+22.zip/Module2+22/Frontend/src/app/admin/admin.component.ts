import { Component, OnInit } from '@angular/core';

export class Admin{
  constructor(
    public aid:number=0,
    public aname:string="",
    public apassword:string=""
  ){}
}


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
