import { Component, OnInit } from '@angular/core';

export class Customer{
  constructor(
    public cid:number=0,
    public cname:string="",
    public cpassword:string=""
  ){}
}
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
