import { Component, OnInit } from '@angular/core';

export class Merchant{
  constructor(
    public mid:number=0,
    public mname:string="",
    public mpassword:string=""
  ){}
}
@Component({
  selector: 'app-merch',
  templateUrl: './merch.component.html',
  styleUrls: ['./merch.component.css']
})
export class MerchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
