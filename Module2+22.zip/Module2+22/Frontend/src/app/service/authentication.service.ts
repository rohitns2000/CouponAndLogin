import { Injectable, OnInit} from '@angular/core'
import {Admin} from '../admin/admin.component'
import {Customer} from '../customer/customer.component'
import {Merchant} from '../merch/merch.component'
import { DataService } from './data.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService implements OnInit{

  ngOnInit(): void {
    alert("at Auth Init....")
  }

  public ad:Admin
  public cu:Customer
  public me:Merchant
  
  public str:string
  public status:boolean=false
  constructor(private service:DataService, private router:Router) { }


  
  authenticate(user,password){
    alert("at authenticate....")

    // this.service.retrieveAdmin(user,password).subscribe(
    //   data=>{
    //     this.ad = data
    //     alert(this.ad.aid)
    //     if(this.ad.aid != 0){
    //     this.str = this.ad.aid+""
    //     sessionStorage.setItem('admin', this.str)
    //     this.router.navigate(['admin'])
    //     alert("Hello1")
    //     }
    //   }
    // )

    // this.service.retrieveCustomer(user,password).subscribe(
    //   data=>{
    //     this.cu = data
    //     alert(this.cu.cid)
    //     if(this.cu.cid != 0){
    //     this.str = this.cu.cid+""
    //     sessionStorage.setItem('customer', this.str)
    //     this.router.navigate(['cust'])
    //     alert("Hello2")
    //     }
        
    //   }
    // )

    // this.service.retrieveMerchant(user,password).subscribe(
    //   data=>{
    //     this.me = data
    //     alert(this.me.mid)
    //     if(this.me.mid != 0){
    //     this.str = this.me.mid+""
    //     sessionStorage.setItem('merchant', this.str)
    //     this.router.navigate(['merch'])
    //     alert("Hello3")
    //     }
        
    //   }
    // )

    alert("Hello4")
    
    }

    isUserLoggedIn(){
      let user = sessionStorage.getItem('authenticaterUser')
      return !(user === null)
  
    }
  
    logout(){
      sessionStorage.removeItem('authenticaterUser')
    }
  //  if(this.trueFalse())
  //  {
  //    return true
  //  }
  //  else{
  //    return false
   }

    // if(!(this.cu.cid === 0))
    // {
    //   this.str = this.cu.cid+""
    //   sessionStorage.setItem('customer', this.str)
    //   return true
    // }

    // if(!(this.ad.aid === 0))
    // {
    //   this.str = this.ad.aid+""
    //   sessionStorage.setItem('admin', this.str)
    //   return true
    // }

    

    // if(!(this.me.mid === 0))
    // {
    //   this.str = this.me.mid+""
    //   sessionStorage.setItem('merchant', this.str)
    //   return true
    // }

   // return false

    

    // if(!this.status){
    //   this.service.retrieveAdmin(user,password).subscribe(
    //     data=>{
    //       alert("in data")
    //       this.ad = data
    //       this.status=true
    //       this.str = this.ad.aid+""
    //       sessionStorage.setItem('admin', this.str)
    //       alert("data finished")
    //       return true
    //     }
    //   )
        
    // }

    // if(!this.status){
    //   this.service.retrieveCustomer(user,password).subscribe(
    //     data=>{
    //       this.cu = data
    //       this.status = true
    //       this.str = this.cu.cid+""
    //       sessionStorage.setItem('customer',this.str)
    //     }
    //   )
    //     return true
    // }

    // if(!this.status){
    //   this.service.retrieveMerchant(user,password).subscribe(
    //     data=>{
    //       this.me = data
    //       this.status = true
    //       this.str = this.me.mid+""
    //       sessionStorage.setItem('merchant',this.str)
    //     }
    //   )
    //   return true
    // }

    // else
    //  {
    //    return false;
    //  }
   

  //  trueFalse(){
  //    if(sessionStorage.getItem('admin'))
  //    {
  //     alert(sessionStorage.getItem('admin'))
  //      return true
  //    }
  //    if(sessionStorage.getItem('customer'))
  //    {
  //      return true
  //    }
  //    if(sessionStorage.getItem('merchant'))
  //    {
  //      return true
  //    }

  //    else {
  //     return false
  //    }
  //  }
 


