import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import {Admin} from '../admin/admin.component'
import {Customer} from '../customer/customer.component'
import {Merchant} from '../merch/merch.component'
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username=''
  password=''
  invalidLogin=false
  errorMessage='Wrong input!!! Please check...'
  userType:string

  public ad:Admin
  public cu:Customer
  public me:Merchant
  public str:string
  public str1:string = "productId here!"

  constructor(private router:Router,private auth:AuthenticationService,private service:DataService) {}
    
  ngOnInit() {
  }

  handelLogin(){

    this.service.retrieveAdmin(this.username,this.password).subscribe(
      data=>{
        this.ad = data
        alert(this.ad.aid)
        if(this.ad.aid != 0){
        this.str = this.ad.aid+""
        sessionStorage.setItem('admin', this.str)
        this.router.navigate(['admin'])
        alert("Hello1")
        alert(sessionStorage.length)
        }else{
          this.service.retrieveCustomer(this.username,this.password).subscribe(
            data=>{
              this.cu = data
              alert(this.cu.cid)
              if(this.cu.cid != 0){
              this.str = this.cu.cid+""
              sessionStorage.setItem('customer', this.str)
              sessionStorage.setItem('productId',this.str1)
              this.router.navigate(['cust'])
              alert("Hello2")
              alert(sessionStorage.length)
              }else{
                this.service.retrieveMerchant(this.username,this.password).subscribe(
                  data=>{
                    this.me = data
                    alert(this.me.mid)
                    if(this.me.mid != 0){
                    this.str = this.me.mid+""
                    sessionStorage.setItem('merchant', this.str)
                    this.router.navigate(['merch'])
                    alert("Hello3")
                    alert(sessionStorage.length)
                    }else{
                      alert("invalid")
                    }
                  }
                )
              }
              
            }
          )
        }
      }
    )

    // this.service.retrieveCustomer(this.username,this.password).subscribe(
    //   data=>{
    //     this.cu = data
    //     alert(this.cu.cid)
    //     if(this.cu.cid != 0){
    //     this.str = this.cu.cid+""
    //     sessionStorage.setItem('customer', this.str)
    //     this.router.navigate(['cust'])
    //     alert("Hello2")
    //     }
        
    //   }
    // )

    // this.service.retrieveMerchant(this.username,this.password).subscribe(
    //   data=>{
    //     this.me = data
    //     alert(this.me.mid)
    //     if(this.me.mid != 0){
    //     this.str = this.me.mid+""
    //     sessionStorage.setItem('merchant', this.str)
    //     this.router.navigate(['merch'])
    //     alert("Hello3")
    //     }
    //   }
    // )
    //  alert(sessionStorage.length)
    

    // this.auth.authenticate(this.username,this.password)
    // alert(sessionStorage.length)
    // if(!(sessionStorage.length === 0)){
      
    //   this.router.navigate(['cust'])
    //   this.invalidLogin=false
    // }
    
    // else
    
    // {
    //   this.invalidLogin=true
    // }
  }


}
