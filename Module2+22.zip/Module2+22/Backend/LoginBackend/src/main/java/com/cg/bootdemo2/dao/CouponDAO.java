package com.cg.bootdemo2.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bootdemo2.entities.Coupon;

public interface CouponDAO extends JpaRepository<Coupon, Integer> {

}
