package com.cg.bootdemo2.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Customer {
@Id
private int cid;
@Column
private String cname;
@Column
private String cpassword;
public Customer(int cid, String cname, String cpassword) {
	super();
	this.cid = cid;
	this.cname = cname;
	this.cpassword = cpassword;
}
public Customer() {
	super();
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCpassword() {
	return cpassword;
}
public void setCpassword(String cpassword) {
	this.cpassword = cpassword;
}
@Override
public String toString() {
	return "Customer [cid=" + cid + ", cname=" + cname + ", cpassword=" + cpassword + "]";
}

}
