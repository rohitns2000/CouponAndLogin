package com.cg.bootdemo2.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bootdemo2.dao.AdminDAO;
import com.cg.bootdemo2.dao.CouponDAO;
import com.cg.bootdemo2.dao.CustomerDAO;
import com.cg.bootdemo2.dao.MerchantDAO;
import com.cg.bootdemo2.entities.Admin;
import com.cg.bootdemo2.entities.Coupon;
import com.cg.bootdemo2.entities.Customer;
import com.cg.bootdemo2.entities.Merchant;


@Service
@Transactional
public class WalletServiceImpl implements WalletService{
	@Autowired AdminDAO dao;
	@Autowired CustomerDAO dao1;
	@Autowired MerchantDAO dao2;
	@Autowired CouponDAO dao3;

	@Override
	public Admin findAdmin(String username,String password) {
		Admin wa1 = null;
		List<Admin> lst = dao.findAll();
		System.out.println(lst);
		for(Admin wa : lst)
		{
			if((wa.getAname().equals(username))&&(wa.getApassword().equals(password))) {
				wa1 = wa;
			}
		}
//		if(wa1 == null)
//		{
//			throw new ApplicationException("No account found in-Admin");
//		}
		return wa1;
	}

	@Override
	public Customer findCustomer(String username, String password) {
		Customer wa1 = null;
		List<Customer> lst = dao1.findAll();
		for(Customer wa : lst)
		{
			if((wa.getCname().equals(username))&&(wa.getCpassword().equals(password))) {
				wa1 = wa;
			}
		}
//		if(wa1 == null)
//		{
//			throw new ApplicationException("No account found in-Customer");
//		}
		return wa1;
	}

	@Override
	public Merchant findMerchant(String username, String password) {
		Merchant wa1 = null;
		List<Merchant> lst = dao2.findAll();
		for(Merchant wa : lst)
		{
			if((wa.getMname().equals(username))&&(wa.getMpassword().equals(password))) {
				wa1 = wa;
			}
		}
//		if(wa1 == null)
//		{
//			throw new ApplicationException("No account found in-Customer");
//		}
		return wa1;
	}


	@Override
	public boolean addAdmin(Admin ad) {
		dao.save(ad);
		return true;
	}

	@Override
	public boolean addCustomer(Customer cu) {
		dao1.save(cu);
		return true;
	}

	@Override
	public boolean addMerchant(Merchant me) {
		dao2.save(me);
		return true;
	}
	
	@Override
	public boolean addCoupon(Coupon co) {
		dao3.save(co);
		return true;
	}

	@Override
	public boolean removeCoupon(Coupon co) {
		dao3.delete(co);
		return true;
	}

	@Override
	public List<Coupon> showAllCoupon() {
		List<Coupon> lst = dao3.findAll();
		return lst;
	}

}
