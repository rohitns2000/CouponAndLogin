package com.cg.bootdemo2.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Admin {
@Id
private int aid;
@Column
private String aname;
@Column
private String apassword;
public Admin(int aid, String aname, String apassword) {
	super();
	this.aid = aid;
	this.aname = aname;
	this.apassword = apassword;
}
public int getAid() {
	return aid;
}
public void setAid(int aid) {
	this.aid = aid;
}
public String getAname() {
	return aname;
}
public void setAname(String aname) {
	this.aname = aname;
}
public String getApassword() {
	return apassword;
}
public void setApassword(String apassword) {
	this.apassword = apassword;
}
public Admin() {
	super();
}
@Override
public String toString() {
	return "Admin [aid=" + aid + ", aname=" + aname + ", apassword=" + apassword + "]";
}


}
